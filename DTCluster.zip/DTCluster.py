import glob
import os
import pickle

import torch.cuda
from PIL import Image
from scipy.spatial.distance import euclidean
from sklearn.cluster import KMeans
from tqdm import trange
import torch.nn as nn
import utils
from Dataset import LM
from get_gpu import get_gpu
from softmax_loss import CrossEntropyLabelSmooth
from matplotlib import pyplot as plt
import numpy as np
import tqdm
import timm
from torchvision import transforms
import torch.nn.functional as F


def my_dunn_index(data, cluster_labels):
    diam_lst = []
    dist_lst = []
    n_cluster = len(np.bincount(cluster_labels))
    cluster_k = [data[cluster_labels == k] for k in range(n_cluster)]
    centroids = [np.mean(k, axis=0) for k in cluster_k]
    cluster_centers = centroids
    # Calculate diameters of cluster
    for k in range(len(cluster_centers)):
        clust_diam_lst = []
        for x in trange(len(data)):
            for y in range(len(data)):
                if cluster_labels[x] == cluster_labels[y] and cluster_labels[x] == k:
                    clust_diam_lst.append(euclidean(data[x], data[y]))
        diam_lst.append(max(clust_diam_lst))
    max_diam = max(diam_lst)

    # Calculate min distance between points in different clusters
    for i in range(len(cluster_centers)):
        for j in range(i + 1, len(cluster_centers)):
            clust_dist_lst = []
            for x in trange(len(data)):
                for y in range(len(data)):
                    if cluster_labels[x] == i and cluster_labels[y] == j:
                        clust_dist_lst.append(euclidean(data[x], data[y]))
            dist_lst.append(min(clust_dist_lst))
    min_dist = min(dist_lst)

    dunn_index = min_dist / max_diam

    return dunn_index


def DaviesBouldin(X, labels):
    n_cluster = len(np.bincount(labels))
    cluster_k = [X[labels == k] for k in range(n_cluster)]
    centroids = [np.mean(k, axis=0) for k in cluster_k]

    # 求S
    S = [np.mean([euclidean(p, centroids[i]) for p in k]) for i, k in enumerate(cluster_k)]
    Ri = []

    for i in range(n_cluster):
        Rij = []

        for j in range(n_cluster):
            if j != i:
                r = (S[i] + S[j]) / euclidean(centroids[i], centroids[j])
                Rij.append(r)

        Ri.append(max(Rij))


    dbi = np.mean(Ri)

    return dbi


trans2 = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),

])


def get_data_(path, label):
    trans = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),

    ])
    train_dataset = LM(path, label, trans)
    train_loader = torch.utils.data.DataLoader(train_dataset, num_workers=4, batch_size=8, shuffle=True,
                                               pin_memory=True)
    return train_loader


def get_data(model):
    trans = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),  # 标准化

    ])
    model = model.cuda()
    model.eval()
    from sklearn.model_selection import train_test_split
    paths = []
    labels = []
    import numpy as np
    b = glob.glob(r'newf/logos_all/*')
    for i in range(len(b)):
        paths.append(b[i])
    labels = [-1 for _ in range(len(paths))]
    test_dataset = LM(paths, labels, trans)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=10, shuffle=False, num_workers=4,
                                              pin_memory=True)
    all_ = []
    with torch.no_grad():
        for i, (x, _) in enumerate(test_loader):
            x = x.cuda()
            fea = model.forward_features(x)
            fea = torch.nn.functional.adaptive_avg_pool2d(x,(1,1)).squeeze(-1).squeeze(-1)
            all_.append(fea.cpu())
    X = torch.cat(all_).cpu().numpy()

    return paths, X

def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)

    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)
def train_model(model, path, y_pred):
    print('123')
    train_loader = get_data_(path, y_pred)
    loss_fn = CrossEntropyLabelSmooth(num_classes=6)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, weight_decay=1e-4)
    model.cuda()
    acc_meter = utils.AverageMeter()
    loss_meter = utils.AverageMeter()
    loader = train_loader
    for epoch in range(1):
        loss_meter.reset()
        acc_meter.reset()
        model.train()
        for i, (x, y) in enumerate(loader):
            x, y = x.cuda(), y.cuda()
            outputs = model(x)
            loss = loss_fn(outputs, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            acc = (outputs.max(1)[1] == y).float().mean()
            loss_meter.update(loss.item(), x.shape[0])
            acc_meter.update(acc, 1)
            print("Epoch[{}] Iteration[{}/{}] Loss: {:.3f}, Acc: {:.3f}, Base Lr: {:.2e}"
                  .format(epoch, (i + 1), len(train_loader),
                          loss_meter.avg, acc_meter.avg, optimizer.state_dict()['param_groups'][0]['lr']))

    return model


for i in range(5):
    print('epoch: ' + str(i))
    if i == 0:
        model = model = timm.create_model('swin_base_patch4_window7_224', pretrained=True, num_classes=6)
    else:
        model = train_model(model, path, y_pred)
    torch.save(model, str(i) + '_res.pt')
    path, X = get_data(model)
    clf = KMeans(6 )
    y_pred = clf.fit_predict(X)
